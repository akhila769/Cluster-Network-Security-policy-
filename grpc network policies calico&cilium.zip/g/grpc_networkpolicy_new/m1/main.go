package main

import (
	"context"
	"fmt"
	"net"
	"net/http"
	"os"
	"os/signal"
	"syscall"
	"time"

	log "github.com/sirupsen/logrus"

	myservice "github.com/akhila2911/myprotos"
	"google.golang.org/grpc"
	"google.golang.org/protobuf/types/known/emptypb"
)

type server struct {
	myservice.UnimplementedHealthCheckServiceServer
}

func (s *server) CheckHealth(ctx context.Context, req *myservice.HealthReq) (*myservice.HealthResp, error) {
	log.Info("m1: Received CheckHealth grpc request from ", req)
	return &myservice.HealthResp{
		Message: "m1: Health check passed",
		Status: &myservice.Status{
			StatusCode: myservice.StatusCode_SUCCESS,
			StatusDescription: &myservice.StatusDescription{
				DescriptionCode: myservice.DescriptionCode_OK,
				Description:     "Service is healthy",
			},
		},
	}, nil
}

func main() {

	go curlGoogle()

	lis, err := net.Listen("tcp", ":5050")
	if err != nil {
		log.Errorf("failed to listen on port 5050 with err: %v", err)
	}

	s := grpc.NewServer()
	myservice.RegisterHealthCheckServiceServer(s, &server{})

	go func() {

		var conn *grpc.ClientConn
		for {
			conn, err = grpc.Dial("m2-service:5051", grpc.WithInsecure())
			if err != nil {
				log.Errorf("Failed to establish client connection with m2 : %v", err)
			} else {
				break
			}
		}
		defer conn.Close()

		client := myservice.NewUserServiceClient(conn)

		for {

			resp, err := client.GetUsers(context.Background(), &emptypb.Empty{})
			if err != nil {
				log.Printf("m1: Failed to call m2 GetUsers: %v", err)
			} else {
				log.Println("m1: Received response from m2 to m1: ", resp)
			}

			time.Sleep(5 * time.Second)
		}
	}()

	sigChan := make(chan os.Signal, 1)
	signal.Notify(sigChan, syscall.SIGINT, syscall.SIGTERM)
	go func() {
		log.Println("Server is starting on port 5050...")
		if err := s.Serve(lis); err != nil {
			log.Fatalf("failed to start gRPC server: %v", err)
		}
	}()

	<-sigChan
	log.Println("Received shutdown signal. Shutting down gracefully...")

	s.GracefulStop()
	log.Println("Server stopped. Port 5050 is now released.")

}

func curlGoogle() {
	// Send GET request to Google
	for {
		resp, err := http.Get("https://www.google.com")
		if err != nil {
			fmt.Println("Error in making request to google:", err)
			time.Sleep(5 * time.Second)
			continue
		}

		// Print status code of the rsesponse
		if resp != nil && resp.Status != "" {
			fmt.Println("Google Response Status:", resp.Status)
			resp.Body.Close()
		}

		time.Sleep(5 * time.Second)
	}
}
