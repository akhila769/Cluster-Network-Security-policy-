package main

import (
	"context"
	"fmt"
	"net/http"
	"time"

	log "github.com/sirupsen/logrus"

	myservice "github.com/akhila2911/myprotos"
	"google.golang.org/grpc"
	"google.golang.org/protobuf/types/known/emptypb"
)

func main() {

	go curlGoogle()

	go makeRpcCallToM1()

	makeRpcCallToM2()
}

func makeRpcCallToM1() {

	var conn *grpc.ClientConn
	var err error

	for {
		conn, err = grpc.Dial("m1-service:5050", grpc.WithInsecure())
		if err != nil {
			log.Errorf("Failed to establish client connection with m1 : %v", err)
		} else {
			break
		}
	}
	defer conn.Close()

	client := myservice.NewHealthCheckServiceClient(conn)

	for {
		resp, err := client.CheckHealth(context.Background(), &myservice.HealthReq{RequestInfo: "m3"})
		if err != nil {
			log.Errorf("m3: Failed to call m1 HealthCheck rpc: %v", err)
		} else {
			log.Println("m3: Received response from m1 to m3: ", resp)
		}
		time.Sleep(5 * time.Second)
	}
}

func makeRpcCallToM2() {
	var conn *grpc.ClientConn
	var err error

	for {
		conn, err = grpc.Dial("m2-service:5051", grpc.WithInsecure())
		if err != nil {
			log.Errorf("m3: Failed to establish client connection with m2 : %v", err)
		} else {
			break
		}
	}
	defer conn.Close()

	client := myservice.NewUserServiceClient(conn)

	for {

		resp, err := client.GetUsers(context.Background(), &emptypb.Empty{})
		if err != nil {
			log.Printf("m3: Failed to call m2 GetUsers: %v", err)
		} else {
			log.Println("m3: Received response from m2 to m3: ", resp)
		}
		time.Sleep(5 * time.Second)
	}
}

func curlGoogle() {
	// Send GET request to Google
	for {
		resp, err := http.Get("https://www.google.com")
		if err != nil {
			fmt.Println("Error in making request to google:", err)
			time.Sleep(5 * time.Second)
			continue
		}

		// Print status code of the response
		if resp != nil && resp.Status != "" {
			fmt.Println("Google Response Status:", resp.Status)
			resp.Body.Close()
		}
		time.Sleep(5 * time.Second)
	}
}
