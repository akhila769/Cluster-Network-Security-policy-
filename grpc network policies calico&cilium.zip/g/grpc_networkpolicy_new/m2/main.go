package main

import (
	"context"
	"fmt"
	"math/rand"
	"net"
	"net/http"
	"os"
	"os/signal"
	"syscall"
	"time"

	myservice "github.com/akhila2911/myprotos"
	emptypb "github.com/golang/protobuf/ptypes/empty"
	log "github.com/sirupsen/logrus"
	"google.golang.org/grpc"
)

type server struct {
	myservice.UnimplementedUserServiceServer
}

func (s *server) GetUsers(context.Context, *emptypb.Empty) (*myservice.GetUsersResp, error) {
	log.Info("m2: Received GetUsers request call")

	id := generateRandomID()
	name := generateRandomName()
	users := []*myservice.User{
		{Id: id, Name: name},
	}

	return &myservice.GetUsersResp{
		Users: users,
		Status: &myservice.Status{
			StatusCode: myservice.StatusCode_SUCCESS,
			StatusDescription: &myservice.StatusDescription{
				DescriptionCode: myservice.DescriptionCode_OK,
				Description:     "Users fetched successfully",
			},
		},
	}, nil
}

func generateRandomName() string {
	names := []string{"Jaya", "Marie", "Suma", "Nokia", "Ndac", "Akhila", "Francis", "Nikhil", "Uday", "Varun"}
	rand.Seed(time.Now().UnixNano())
	return names[rand.Intn(len(names))]
}

func generateRandomID() int64 {
	return rand.Int63n(9000) + 1000
}

func main() {

	go curlGoogle()
	lis, err := net.Listen("tcp", ":5051")
	if err != nil {
		log.Fatalf("failed to listen on port 5051: %v", err)
	}

	s := grpc.NewServer()
	myservice.RegisterUserServiceServer(s, &server{})

	go func() {
		var conn *grpc.ClientConn
		for {
			conn, err = grpc.Dial("m1-service:5050", grpc.WithInsecure())
			if err != nil {
				log.Fatalf("Failed to establish client connection with m1 : %v", err)
			} else {
				break
			}
		}
		defer conn.Close()

		client := myservice.NewHealthCheckServiceClient(conn)

		for {
			resp, err := client.CheckHealth(context.Background(), &myservice.HealthReq{RequestInfo: "m2"})
			if err != nil {
				log.Errorf("m2: Failed to call m1 HealthCheck rpc: %v", err)
			} else {
				log.Println("m2: Received response from m1 to m2: ", resp)
			}
			time.Sleep(5 * time.Second)
		}
	}()

	sigChan := make(chan os.Signal, 1)
	signal.Notify(sigChan, syscall.SIGINT, syscall.SIGTERM)

	go func() {
		log.Println("Server is starting on port 5050...")
		if err := s.Serve(lis); err != nil {
			log.Fatalf("failed to start gRPC server: %v", err)
		}
	}()

	<-sigChan
	log.Println("Received shutdown signal. Shutting down gracefully...")

	s.GracefulStop()
	log.Println("Server stopped. Port 5050 is now released.")
}

func curlGoogle() {
	// Send GET request to Google
	for {
		resp, err := http.Get("https://www.google.com")
		if err != nil {
			fmt.Println("Error in making request to google:", err)
			time.Sleep(5 * time.Second)
			continue
		}

		// Print status code of the response
		if resp != nil && resp.Status != "" {
			fmt.Println("Google Response Status:", resp.Status)
			resp.Body.Close()
		}

		time.Sleep(5 * time.Second)
	}
}
